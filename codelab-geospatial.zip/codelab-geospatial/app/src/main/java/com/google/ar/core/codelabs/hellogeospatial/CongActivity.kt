package com.google.ar.core.codelabs.hellogeospatial

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class CongActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cong)

        val navigateButton = findViewById<Button>(R.id.navigateButton) // Replace with your button ID
        navigateButton.setOnClickListener {
            val intent = Intent(this@CongActivity, NavActivity::class.java)
            startActivity(intent)
        }

    }
}