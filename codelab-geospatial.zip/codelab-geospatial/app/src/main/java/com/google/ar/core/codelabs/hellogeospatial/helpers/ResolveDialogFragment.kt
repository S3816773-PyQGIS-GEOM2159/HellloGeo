package com.google.ar.core.codelabs.hellogeospatial.helpers

import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.text.InputFilter
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import androidx.fragment.app.DialogFragment

class ResolveDialogFragment : DialogFragment() {

    companion object {
        private const val MAX_FIELD_LENGTH = 50 // Adjust as needed

        fun createWithOkListener(listener: OkListener): ResolveDialogFragment {
            val frag = ResolveDialogFragment()
            frag.okListener = listener
            return frag
        }
    }

    interface OkListener {
        fun onOkPressed(dialogValue: String) // Adjusted to accept a String
    }

    private var shortCodeField: EditText? = null
    private var okListener: OkListener? = null

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val builder = AlertDialog.Builder(activity)
        builder.setView(createDialogLayout())
            .setTitle("Resolve Anchor")
            .setPositiveButton("Resolve") { _, _ -> onResolvePressed() }
            .setNegativeButton("Cancel") { dialog, _ -> dialog.cancel() }
        return builder.create()
    }

    private fun createDialogLayout(): LinearLayout {
        val context: Context = requireContext()
        val layout = LinearLayout(context)
        shortCodeField = EditText(context).apply {
            inputType = InputType.TYPE_CLASS_TEXT // Allowing text input
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            filters = arrayOf<InputFilter>(InputFilter.LengthFilter(MAX_FIELD_LENGTH))
        }
        layout.addView(shortCodeField)
        layout.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        return layout
    }

    private fun onResolvePressed() {
        val roomCodeText = shortCodeField?.text
        if (okListener != null && roomCodeText != null && roomCodeText.isNotEmpty()) {
            okListener?.onOkPressed(roomCodeText.toString()) // Passing the string directly
        }
    }
}

