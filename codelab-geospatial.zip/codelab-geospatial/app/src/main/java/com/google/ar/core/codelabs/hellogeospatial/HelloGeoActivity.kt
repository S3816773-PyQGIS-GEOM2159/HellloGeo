/*
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.ar.core.codelabs.hellogeospatial

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.ar.core.Config
import com.google.ar.core.Session
import com.google.ar.core.codelabs.hellogeospatial.helpers.ARCoreSessionLifecycleHelper
import com.google.ar.core.codelabs.hellogeospatial.helpers.GeoPermissionsHelper
import com.google.ar.core.codelabs.hellogeospatial.helpers.HelloGeoView
import com.google.ar.core.examples.java.common.helpers.FullScreenHelper
import com.google.ar.core.examples.java.common.samplerender.SampleRender
import com.google.ar.core.exceptions.CameraNotAvailableException
import com.google.ar.core.exceptions.UnavailableApkTooOldException
import com.google.ar.core.exceptions.UnavailableDeviceNotCompatibleException
import com.google.ar.core.exceptions.UnavailableSdkTooOldException
import com.google.ar.core.exceptions.UnavailableUserDeclinedInstallationException
import com.google.ar.core.Config.CloudAnchorMode
import java.util.concurrent.Future
import com.google.ar.core.Anchor
import com.google.ar.core.codelabs.hellogeospatial.helpers.ResolveDialogFragment
import com.google.ar.core.codelabs.hellogeospatial.helpers.StorageManager
import android.os.Handler
import android.os.Looper

class HelloGeoActivity : AppCompatActivity() {

  companion object {
    private const val TAG = "HelloGeoActivity"

  }

  private var currentAnchor: Anchor? = null
  private var future: Future<*>? = null
  var resolveButton: Button? = null
  val session get() = arCoreSessionHelper.session
  private lateinit var progressBar: ProgressBar

  lateinit var arCoreSessionHelper: ARCoreSessionLifecycleHelper
  lateinit var view: HelloGeoView
  lateinit var renderer: HelloGeoRenderer

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)

    // Setup ARCore session lifecycle helper and configuration.
    arCoreSessionHelper = ARCoreSessionLifecycleHelper(this)
    // If Session creation or Session.resume() fails, display a message and log detailed
    // information.
    arCoreSessionHelper.exceptionCallback =
      { exception ->
        val message =
          when (exception) {
            is UnavailableUserDeclinedInstallationException ->
              "Please install Google Play Services for AR"

            is UnavailableApkTooOldException -> "Please update ARCore"
            is UnavailableSdkTooOldException -> "Please update this app"
            is UnavailableDeviceNotCompatibleException -> "This device does not support AR"
            is CameraNotAvailableException -> "Camera not available. Try restarting the app."
            else -> "Failed to create AR session: $exception"
          }
        Log.e(TAG, "ARCore threw an exception", exception)
        view.snackbarHelper.showError(this, message)
      }

    // Configure session features.
    arCoreSessionHelper.beforeSessionResume = ::configureSession
    lifecycle.addObserver(arCoreSessionHelper)

    // Set up the Hello AR renderer.
    renderer = HelloGeoRenderer(this)
    lifecycle.addObserver(renderer)

    // Set up Hello AR UI.
    view = HelloGeoView(this)
    lifecycle.addObserver(view)
    setContentView(view.root)

    // Sets up an example renderer using our HelloGeoRenderer.
    SampleRender(view.surfaceView, renderer, assets)

    progressBar = findViewById(R.id.progressBar)

    val openButton = findViewById<Button>(R.id.openButton)
    openButton.setOnClickListener {
      val intent = Intent(this@HelloGeoActivity, CongActivity::class.java)
      startActivity(intent)
    }

    resolveButton = findViewById<Button>(R.id.resolve_button).apply {
      setOnClickListener {
        onResolveButtonPressed()
        val dialog = ResolveDialogFragment()
        dialog.show(supportFragmentManager, "Resolve")
      }
    }
  }

  fun configureSession(session: Session) {
    val config = Config(session).apply {
      geospatialMode = Config.GeospatialMode.ENABLED
      cloudAnchorMode = CloudAnchorMode.ENABLED
    }
    session.configure(config)
  }

  private val storageManager = StorageManager()

  override fun onRequestPermissionsResult(
    requestCode: Int,
    permissions: Array<String>,
    results: IntArray
  ) {
    super.onRequestPermissionsResult(requestCode, permissions, results)
    if (!GeoPermissionsHelper.hasGeoPermissions(this)) {
      // Use toast instead of snackbar here since the activity will exit.
      Toast.makeText(
        this,
        "Camera and location permissions are needed to run this application",
        Toast.LENGTH_LONG
      )
        .show()
      if (!GeoPermissionsHelper.shouldShowRequestPermissionRationale(this)) {
        // Permission denied with checking "Do not ask again".
        GeoPermissionsHelper.launchPermissionSettings(this)
      }
      finish()
    }
  }

  override fun onWindowFocusChanged(hasFocus: Boolean) {
    super.onWindowFocusChanged(hasFocus)
    FullScreenHelper.setFullScreenOnWindowFocusChanged(this, hasFocus)
  }

  fun onHostComplete(cloudAnchorId: String, cloudState: Anchor.CloudAnchorState) {
    if (cloudState == Anchor.CloudAnchorState.SUCCESS) {
      Log.d("CloudAnchor", "Hosted Anchor ID: $cloudAnchorId")
      val shortCode =
        storageManager.nextShortCode(this) // replace 'this' with 'activity' if you are in a Fragment
      storageManager.storeUsingShortCode(
        this,
        shortCode,
        cloudAnchorId
      ) // replace 'this' with 'activity' if you are in a Fragment
      Toast.makeText(this, "Cloud Anchor Hosted. Short code: $shortCode", Toast.LENGTH_SHORT)
        .show() // replace with your message display logic
    } else {
      Toast.makeText(this, "Error while hosting: $cloudState", Toast.LENGTH_SHORT)
        .show() // replace with your message display logic
    }
  }

  fun onShortCodeEntered(shortCode: String) {
    val cloudAnchorId = storageManager.getCloudAnchorId(this, shortCode)
    Log.d("CloudAnchor", "Attempting to resolve Cloud Anchor with ID: $cloudAnchorId")

    if (cloudAnchorId.isNullOrEmpty()) {
      Toast.makeText(this, "A Cloud Anchor ID for the short code $shortCode was not found.", Toast.LENGTH_SHORT).show()
      resolveButton?.isEnabled = true
      return
    }

    arCoreSessionHelper.session?.let { session ->
      try {
        val anchor = session.resolveCloudAnchor(cloudAnchorId)
        Log.d("CloudAnchor", "Cloud Anchor State: ${anchor.cloudAnchorState}")

        when (anchor.cloudAnchorState) {
          Anchor.CloudAnchorState.SUCCESS -> onResolveComplete(anchor, anchor.cloudAnchorState, shortCode)

          Anchor.CloudAnchorState.TASK_IN_PROGRESS -> {
            Toast.makeText(this, "Task in progress. Please wait...", Toast.LENGTH_SHORT).show()

            // Retry mechanism
            val handler = Handler(Looper.getMainLooper())
            val retryRunnable = object : Runnable {
              var retryCount = 0
              override fun run() {
                if (anchor.cloudAnchorState == Anchor.CloudAnchorState.TASK_IN_PROGRESS && retryCount < 5) { // Retry up to 5 times
                  Log.d("CloudAnchor", "Retrying... Attempt: ${retryCount + 1}")
                  retryCount++
                  handler.postDelayed(this, 10000) // Retry after 10 seconds
                } else if (anchor.cloudAnchorState == Anchor.CloudAnchorState.SUCCESS) {
                  onResolveComplete(anchor, anchor.cloudAnchorState, shortCode)
                } else {
                  Toast.makeText(this@HelloGeoActivity, "Failed to resolve anchor after $retryCount attempts.", Toast.LENGTH_SHORT).show()
                }
              }
            }
            handler.post(retryRunnable)
          }

          else -> {
            Toast.makeText(this, "Error while resolving anchor: ${anchor.cloudAnchorState}", Toast.LENGTH_SHORT).show()
            Log.e("CloudAnchor", "Failed to resolve anchor. State: ${anchor.cloudAnchorState}")
          }
        }
      } catch (e: Exception) {
        Toast.makeText(this, "Error while resolving anchor: ${e.message}", Toast.LENGTH_SHORT).show()
        Log.e("CloudAnchor", "Exception while resolving anchor", e)
      } finally {
        resolveButton?.isEnabled = true
        progressBar.visibility = View.GONE
      }
    } ?: run {
      Toast.makeText(this, "ARCore Session is not available.", Toast.LENGTH_SHORT).show()
      resolveButton?.isEnabled = true
      progressBar.visibility = View.GONE
    }
  }

  private fun onResolveComplete(
    anchor: Anchor?,
    cloudState: Anchor.CloudAnchorState,
    shortCode: String
  ) {
    progressBar.visibility = View.GONE // Hide the ProgressBar

    if (cloudState == Anchor.CloudAnchorState.SUCCESS) {
      Toast.makeText(this, "Cloud Anchor Resolved. Short code: $shortCode", Toast.LENGTH_SHORT)
        .show()
      currentAnchor = anchor
      renderer.updateAnchor(anchor)




    } else {
      Toast.makeText(this, "Error  $shortCode. Error: $cloudState", Toast.LENGTH_LONG).show()
      resolveButton?.isEnabled = true
    }
  }

  private fun onResolveButtonPressed() {
    resolveButton?.isEnabled = false
    progressBar.visibility = View.VISIBLE

    val dialog =
      ResolveDialogFragment.createWithOkListener(object : ResolveDialogFragment.OkListener {
        override fun onOkPressed(dialogValue: String) { // Adjusted to accept a String
          onShortCodeEntered(dialogValue) // Passing the string directly
        }
      })
    dialog.show(supportFragmentManager, "Resolve")
  }
}


