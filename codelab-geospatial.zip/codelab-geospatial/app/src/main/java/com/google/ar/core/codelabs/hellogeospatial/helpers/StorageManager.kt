package com.google.ar.core.codelabs.hellogeospatial.helpers

import android.app.Activity
import android.content.Context

/** Helper class for managing on-device storage of cloud anchor IDs. */
class StorageManager {
    companion object {
        private const val SHARED_PREFS_NAME = "cloud_anchor_codelab_short_codes"
        private const val NEXT_SHORT_CODE = "next_short_code"
        private const val KEY_PREFIX = "anchor;"
        private const val INITIAL_SHORT_CODE = 1
    }

    /** Gets a new short code that can be used to store the anchor ID. */
    fun nextShortCode(activity: Activity): Int {
        val sharedPrefs = activity.getSharedPreferences(SHARED_PREFS_NAME, Context.MODE_PRIVATE)
        val shortCode = sharedPrefs.getInt(NEXT_SHORT_CODE, INITIAL_SHORT_CODE)
        sharedPrefs.edit().putInt(NEXT_SHORT_CODE, shortCode + 1).apply()
        return shortCode
    }

    /** Stores the cloud anchor ID in the activity's SharedPreferences. */
    fun storeUsingShortCode(activity: Activity, shortCode: Int, cloudAnchorId: String) {
        val sharedPrefs = activity.getPreferences(Context.MODE_PRIVATE)
        sharedPrefs.edit().putString("$KEY_PREFIX$shortCode", cloudAnchorId).apply()
    }

    /**
     * Retrieves the cloud anchor ID using a short code. Returns an empty string if a cloud anchor ID
     * was not stored for this short code.
     */
    fun getCloudAnchorId(activity: Activity, shortCode: String): String {
        val sharedPrefs = activity.getPreferences(Context.MODE_PRIVATE)
        return sharedPrefs.getString("$KEY_PREFIX$shortCode", "") ?: ""
    }
}